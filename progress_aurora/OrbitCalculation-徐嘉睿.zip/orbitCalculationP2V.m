function [velocityAp,wAp,velocityPe,wPe] = orbitCalculationP2V(aph,peh)
velocityAp=(((2*6.67259*10^(-11)*5.965*10^(24)*(peh*1000+6374500))/((aph*1000+6374500)*((aph+peh)*1000+2*6374500)))^(1/2))/1000;
wAp=1000*velocityAp/(aph*1000+6374500);
velocityPe=(((2*6.67259*10^(-11)*5.965*10^(24)*(aph*1000+6374500))/((peh*1000+6374500)*((aph+peh)*1000+2*6374500)))^(1/2))/1000;
wPe=1000*velocityPe/(peh*1000+6374500);
end

%% This program is to calculate the velocity of the probe when it at the aph and peh of the orbit
%% The input arguement are the ellipse orbit aph (apoapsis height/highest height: apoapsis radius - earth radius) (unit: km)  
%% and peh (periapsis height/lowest height: periapsis radius - earth radius) (unit: km)
%% The output is the linear velocity (unit: km/s) and angular velocity (unit: rad/s) of the porbe at that positions
%% This program is suitable for ellipse orbit.