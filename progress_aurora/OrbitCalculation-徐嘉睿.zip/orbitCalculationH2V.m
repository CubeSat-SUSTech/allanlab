function [velocity,wv] = orbitCalculationH2V(aph,peh,h)
[Vap,~]=orbitCalculationP(aph,peh);
velocity=(((Vap*1000)^2+2*6.67259*10^(-11)*5.965*10^24*(((aph*1000+6374500)-(h*1000+6374500))/((aph*1000+6374500)*(h*1000+6374500))))^(1/2))/1000;
wv=1000*velocity/(h*1000+6374500);
end

%% This program is to calculate the velocity of the probe when the height of it is h (unit: km)
%% The input arguements are the aph (apoapsis height/highest height: apoapsis radius - earth radius) (unit: km) 
%% and peh (periapsis height/lowest height: periapsis radius - earth radius) (unit: km) and h mentioned above
%% The output is the linear velocity (unit: km/s) and angular velocity (unit: rad/s) of the porbe at that position
%% This program is suitable for ellipse orbit.