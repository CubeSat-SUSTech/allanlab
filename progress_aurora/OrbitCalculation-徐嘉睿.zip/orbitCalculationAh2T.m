function [period] = orbitCalculationAh2T(aph)
period=(((4*pi^2)*(aph*1000+6374500)^3)/(6.67259*10^(-11)*5.965*10^24))^(1/2);
end

%% This program is to calculate the period of the probe 
%% The input arguement is the aph (apoapsis height/highest height: apoapsis radius - earth radius) (unit: km) 
%% The output is the period (unit: s) mentioned above
%% This program is suitable for ellipse orbit