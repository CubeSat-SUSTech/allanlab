function [height] = orbitCalculationCT2H(period)
height=((6.67259*10^(-11)*5.965*10^(24)*period^2/(4*pi^2))^(1/3)-6374500)/1000;
end

%% This program is to calculate the height (unit: km) of the probe when its circular orbit period is known.
%% The input arguement is the circluar the period of the probe (unit: s)
%% The output is the height of the probe (orbit radius - earth radius)
%% ATTENTION: This program can only calculate CIRCULAR orbit info!