function [period] = orbitCalculationCH2T(height)
period=(((4*pi^2)*(height*1000+6374500)^3)/(6.67259*10^(-11)*5.965*10^(24)))^(1/2);
end

%% This program is to calculate the period (unit: s) of the probe when its circular orbit height is known.
%% The input arguement is the circluar the height (unit: km) of the probe (orbit radius - earth radius)
%% The output is the period (unit: s) of the probe
%% ATTENTION: This program can only calculate CIRCULAR orbit info!